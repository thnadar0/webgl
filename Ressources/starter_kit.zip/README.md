dist = distributed, for testing/beta
build = final version, compressed and everything
