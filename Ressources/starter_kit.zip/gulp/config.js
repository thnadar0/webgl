var src = "./src/"

module.exports = {
  paths: {
    build: "./build/",

    src: src,

    scripts: src + "scripts/"
  }
}
